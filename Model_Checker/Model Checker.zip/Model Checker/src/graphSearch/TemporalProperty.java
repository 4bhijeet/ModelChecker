package graphSearch;

public enum TemporalProperty {
	AX, EX, AG, EG, AF, EF, AU, EU
}
