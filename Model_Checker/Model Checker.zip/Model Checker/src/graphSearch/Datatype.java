package graphSearch;

public enum Datatype {
	INTEGER,
	FLOAT,
	DOUBLE,
	BOOLEAN,
	STRING
}
