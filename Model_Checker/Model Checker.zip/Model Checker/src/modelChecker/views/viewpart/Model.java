package modelChecker.views.viewpart;

public enum Model {
	DESIGN_TIME_MODEL, RUNTIME_MODEL
}
